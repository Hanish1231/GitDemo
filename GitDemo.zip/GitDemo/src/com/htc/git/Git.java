package com.htc.git;

public class Git {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number = 4;
		if(number%2==0)
		{
			System.out.println("Even number");
		}
		else
		{
			System.out.println("Odd number");
		}
	}

}
